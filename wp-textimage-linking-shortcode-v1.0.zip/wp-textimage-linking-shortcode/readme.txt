=== WP Text/Image Linking Shortcode ===
Contributors: ircary
Donate link: http://lookclassy.com/
Tags: shortcode, linking
Requires at least: 3.0
Tested up to: 3.7
Stable tag: 1.0
License: GPLv3 or later
License URI: http://opensource.org/licenses/GPL-3.0

Use linking short codes to save you time and eliminate stress when restructuring your site pages & post.


== Description ==
Use linking short codes to save you time and eliminate stress when restructuring your site pages & post.


== Installation ==
	1. Upload the zip file contents to your Wordpress plugins directory.
	2. Go to the Plugins page in your WordPress Administration area and click 'Activate' for WP Text/Image Linking Shortcode.

== Screenshots ==
	none

== Frequently Asked Questions ==
	none


== Upgrade Notice ==
	none


== Changelog ==
	= 1.0 =
		- First Release
