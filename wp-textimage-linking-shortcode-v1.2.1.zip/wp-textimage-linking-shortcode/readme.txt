=== LCT Text/Image Linking Shortcode ===
Contributors: ircary
Donate link: http://lookclassy.com/
Tags: shortcode, linking
Requires at least: 3.0
Tested up to: 3.8.1
Stable tag: 1.2.1
License: GPLv3 or later
License URI: http://opensource.org/licenses/GPL-3.0

Use linking short codes to save you time and eliminate stress when restructuring your site pages & post.


== Description ==
Use linking short codes to save you time and eliminate stress when restructuring your site pages & post.

Available Attributes:
- id
- text
- class
- alt
- esc_html
- rel
- src
- style
- title


== Installation ==
1. Upload the zip file contents to your Wordpress plugins directory.
2. Go to the Plugins page in your WordPress Administration area and click 'Activate' for WP Text/Image Linking Shortcode.

== Screenshots ==
none

== Frequently Asked Questions ==
none


== Upgrade Notice ==
none


== Changelog ==
= 1.2.1 =
	- Add an "anchor" attribute

= 1.2 =
	- Tested for WP 3.8.1 Compapibility
	- Changed name to LCT Text/Image Linking Shortcode form WP Text/Image Linking Shortcode

= 1.1 =
	- Tested for WP 3.8 Compapibility

= 1.0.1 =
	- Fixed post_type bug
	- Added alt attribute
	- Updated readme.txt

= 1.0 =
	- First Release
